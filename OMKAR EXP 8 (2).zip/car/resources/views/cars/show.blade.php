@extends('layout')

@section('mainContent')
	<h1>Show Car</h1><br>
	<div style="color: {{$carid->color}}">
		<h1>Car Name : {{$carid->name}}</h1>
        <p><strong>Car Color : {{$carid->color}}</strong></p>
	</div>
	<p>
		<strong>Company Name : {{$carid->company}}</strong>
	</p>
@endsection
